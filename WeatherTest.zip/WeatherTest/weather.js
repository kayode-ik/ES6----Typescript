const today = new Date();
const date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
document.getElementById("currentDate").value = date;

console.log(date);

// Firt Api fetch Current Weather -------------------
var input = document.querySelector('.input_text');
const main = document.querySelector('#name');
const latitude = document.querySelector('.lat');
const longitude = document.querySelector('.long');
const currentTime = document.querySelector('.current_time');
const sunriseTemp = document.querySelector('.sunrise_temp');
const sunsetTemp = document.querySelector('.sunset_temp');
const temp = document.querySelector('.temp');
const pressure = document.querySelector('.pressure');
const windSpeed = document.querySelector('.wind_speed');
const windDir = document.querySelector('.wind_direction');
const weatherDesc = document.querySelector('.desc');
const icon = document.querySelector('.icon');
// End Current Weather -------------------

// Firt Api fetch  Hourly  Weather -------------------
const hourlyTemp = document.querySelector('.__temp');
const hourlyPressure = document.querySelector('.__pressure');
const hourlyWindspeed = document.querySelector('.__windspeed');
const hourlyWinddirection = document.querySelector('.__winddirection');
const hourlyDescription = document.querySelector('.__desc');
const hourlyPop = document.querySelector('.__pop');
const hourlyicon = document.querySelector('.__icon');
// End Hourly  Weather -------------------


// Second Api fetch Current Weather -------------------
var input_one = document.querySelector('.input_city');
const main_one = document.querySelector('#name1');
const latitude_one = document.querySelector('.lat1');
const longitude_one = document.querySelector('.long1');
const currentTime_one = document.querySelector('.current_time1');
const sunriseTemp_one = document.querySelector('.sunrise_temp1');
const sunsetTemp_one = document.querySelector('.sunset_temp1');
const temp_one = document.querySelector('.temp1');
const pressure_one = document.querySelector('.pressure1');
const windSpeed_one = document.querySelector('.wind_speed1');
const windDir_one = document.querySelector('.wind_direction1');
const weatherDesc_one = document.querySelector('.desc1');
const icon_one = document.querySelector('.icon1');



// Second Api Hourly  Weather -------------------
const hourlyTemp_one = document.querySelector('.__temp2');
const hourlyPressure_one = document.querySelector('.__pressure2');
const hourlyWindspeed_one = document.querySelector('.__windspeed2');
const hourlyWinddirection_one = document.querySelector('.__winddirection2');
const hourlyDescription_one = document.querySelector('.__desc2');
const hourlyPop_one = document.querySelector('.__pop2');
const hourlyicon_one = document.querySelector('.__icon2');
// End Hourly  Weather -------------------


const celsiusValue = document.getElementById("celsius");
const fahrenheitValue = document.getElementById("fahrenheit");
let weatherReportData;
let weatherReportData2;
let kelvinValue = 0;
let kelvinValue2 = 0;
let timeoutRef = null;
let useCelcus = true;

// Populate field of first column
const populateCurrentWeather = (data) => {

    
    weatherReportData = data;
    var nameValue = data['name'];
    var latValue = data['coord']['lon'];
    var longValue = data['coord']['lat'];
    var currTimeValue = data['timezone'];
    var sunriseValue = data['sys']['sunrise'];
    var sunsetValue = data['sys']['sunset'];
    var tempValue = kelvinValue = Math.floor(data['main']['temp']);
    var pressureValue = data['main']['pressure'];
    var windSpeedValue = data['wind']['speed'];
    var windDirValue = data['wind']['deg'];
    var descValue = data['weather'][0]['description'];
    var iconValue = "https://openweathermap.org/img/w/" + data['weather'][0]['icon'] + ".png";
    console.log(iconValue);


    input.value = "";
    main.innerHTML = nameValue;
    latitude.innerHTML = "Latitude - " + latValue;
    longitude.innerHTML = "Longitute - " + longValue;
    currentTime.innerHTML = "Current Time - " + currTimeValue;
    sunriseTemp.innerHTML = "Sunrise Time - " + sunriseValue;
    sunsetTemp.innerHTML = "Sunset Time - " + sunsetValue;
    temp.innerHTML = "Temperature - " + tempValue;
    pressure.innerHTML = "Pressure - " + pressureValue;
    windSpeed.innerHTML = "Wind Speed - " + windSpeedValue;
    windDir.innerHTML = "Wind Direction - " + windDirValue + "Degrees";
    weatherDesc.innerHTML = "Weather Desc - " + descValue;
    icon.setAttribute('src', iconValue)


    return {latValue, longValue}
}
// Populate field of first column
const getHourlyWeather = (body) => {
    var hourlytempValue = kelvinValue = Math.floor(body['hourly'][0]['temp']);
    var hourlypressureValue = body['hourly'][0]['pressure'];
    var hourlywindSpeedValue = body['hourly'][0]['wind_speed'];
    var hourlywindDirValue = body['hourly'][0]['wind_deg'];
    var hourlydescValue = body['hourly'][0]['weather'][0]['description'];
    var hourlypop = body['hourly'][0]['pop'];
    var houricon = "https://openweathermap.org/img/w/" + body['hourly'][0]['weather'][0]['icon'] + ".png";


    hourlyTemp.innerHTML = "Temperature - " + hourlytempValue;
    hourlyPressure.innerHTML = "Pressure - " + hourlypressureValue;
    hourlyWindspeed.innerHTML = "Wind Speed - " + hourlywindSpeedValue;
    hourlyWinddirection.innerHTML = "Wind Direction - " + hourlywindDirValue + "Degrees";
    hourlyDescription.innerHTML = "Weather Desc - " + hourlydescValue;
    hourlyPop.innerHTML = "Probability of Precipitation  - " + hourlypop;
    hourlyicon.setAttribute('src', houricon)

    // hourlyicon.setAttribute('src', houricon)

}

//  EventListener for the first column API call
input.addEventListener('input', function (name) {
    if (timeoutRef !== null) {
        clearTimeout(timeoutRef);
    }
    timeoutRef = setTimeout(() => {
        fetch('http://api.openweathermap.org/data/2.5/weather?q=' + input.value + '&appid=76ae57951f3004ff91ac63d3cce42eec')
            .then(response => response.json())
            .then(data => {
                // window.localStorage.setItem("weather_report", JSON.stringify(data));
                // console.log(JSON.parse(window.localStorage.getItem("weather_report")));
                const  {latValue, longValue} = populateCurrentWeather(data);
                return fetch(`https://api.openweathermap.org/data/2.5/onecall?lat=${latValue}&lon=${longValue}&exclude=minutely,daily&appid=76ae57951f3004ff91ac63d3cce42eec`)

            })
            .catch(err => {
                alert("Wrong City name")
            })
            .then(response => response.json())
            .then(body => {
                console.log(body)
                if (body) {
                    console.log(localStorage.getItem('_fake'));
                    getHourlyWeather(body)
                    localStorage.setItem('_fake', JSON.stringify({ weatherReportData, hourData: body }))
                }
            })

            .catch(err => console.log(err));
    }, 1000);

})

// Populate first column on reload
const populateOnReload = () => {
    const {weatherReportData, hourData} = JSON.parse(localStorage.getItem('_fake'))
    console.log(weatherReportData, hourData);
    populateCurrentWeather(weatherReportData);
    getHourlyWeather (hourData);
}

// Populate field of second column
const populateCurrentWeather2 = (data) => {


    weatherReportData2 = data;
    var nameValue_one = data['name'];
    var latValue_one = data['coord']['lon'];
    var longValue_one = data['coord']['lat'];
    var currTimeValue_one = data['timezone'];
    var sunriseValue_one = data['sys']['sunrise'];
    var sunsetValue_one = data['sys']['sunset'];
    var tempValue_one = kelvinValue2 = Math.floor(data['main']['temp']);
    var pressureValue_one = data['main']['pressure'];
    var windSpeedValue_one = data['wind']['speed'];
    var windDirValue_one = data['wind']['deg'];
    var descValue_one = data['weather'][0]['description'];
    var iconValue_one = "https://openweathermap.org/img/w/" + data['weather'][0]['icon'] + ".png";


    input_one.value = "";
    main_one.innerHTML = nameValue_one;
    latitude_one.innerHTML = "Latitude - " + latValue_one;
    longitude_one.innerHTML = "Longitute - " + longValue_one;
    currentTime_one.innerHTML = "Current Time - " + currTimeValue_one;
    sunriseTemp_one.innerHTML = "Sunrise Time - " + sunriseValue_one;
    sunsetTemp_one.innerHTML = "Sunset Time - " + sunsetValue_one;
    temp_one.innerHTML = "Temperature - " + tempValue_one;
    pressure_one.innerHTML = "Pressure - " + pressureValue_one;
    windSpeed_one.innerHTML = "Wind Speed - " + windSpeedValue_one;
    windDir_one.innerHTML = "Wind Direction - " + windDirValue_one + "Degrees";
    weatherDesc_one.innerHTML = "Description - " + descValue_one;
    icon_one.setAttribute('src', iconValue_one)


    return {latValue_one, longValue_one}
}
// Populate field of second column
const getHourlyWeather2 = (body2) => {
    var hourlytempValue_one = kelvinValue = Math.floor(body2['hourly'][0]['temp']);
    var hourlypressureValue_one = body2['hourly'][0]['pressure'];
    var hourlywindSpeedValue_one = body2['hourly'][0]['wind_speed'];
    var hourlywindDirValue_one = body2['hourly'][0]['wind_deg'];
    var hourlydescValue_one = body2['hourly'][0]['weather'][0]['description'];
    var hourlypop_one = body2['hourly'][0]['pop'];
    var houricon_one = "https://openweathermap.org/img/w/" + body2['hourly'][0]['weather'][0]['icon'] + ".png";


    hourlyTemp_one.innerHTML = "Temperature - " + hourlytempValue_one;
    hourlyPressure_one.innerHTML = "Pressure - " + hourlypressureValue_one;
    hourlyWindspeed_one.innerHTML = "Wind Speed - " + hourlywindSpeedValue_one;
    hourlyWinddirection_one.innerHTML = "Wind Direction - " + hourlywindDirValue_one + "Degrees";
    hourlyDescription_one.innerHTML = "Weather Desc - " + hourlydescValue_one;
    hourlyPop_one.innerHTML = "Probability of Precipitation  - " + hourlypop_one;
    hourlyicon_one.setAttribute('src', houricon_one)

}

//  EventListener for the second column API call
input_one.addEventListener('input', function (name) {
    if (timeoutRef !== null) {
        clearTimeout(timeoutRef);
    }
    timeoutRef = setTimeout(() => {
        fetch('http://api.openweathermap.org/data/2.5/weather?q=' + input_one.value + '&appid=76ae57951f3004ff91ac63d3cce42eec')
            .then(response => response.json())
            .then(data => {

                const  {latValue_one, longValue_one} = populateCurrentWeather2(data);
                return fetch(`https://api.openweathermap.org/data/2.5/onecall?lat=${latValue_one}&lon=${longValue_one}&exclude=minutely,daily&appid=76ae57951f3004ff91ac63d3cce42eec`)
 
            })

            .catch(err => {
                alert("Wrong City name")
            })
            .then(response => response.json())
            .then(body2 => {
                console.log(body2)
                if (body2) {
                    // console.log(localStorage.getItem('_fake2'));
                    getHourlyWeather2(body2)
                    localStorage.setItem('_fake2', JSON.stringify({ weatherReportData2, hourData2: body2 }))
                }
            })

            .catch(err => console.log(err));
    }, 1000);

})

// Populate Second column on reload
const populateOnReload2 = () => {
    const {weatherReportData2, hourData2} = JSON.parse(localStorage.getItem('_fake2'))
    console.log(weatherReportData2, hourData2);
    populateCurrentWeather2(weatherReportData2);
    getHourlyWeather2 (hourData2);
}

//Get Radio buttons
celsiusValue.addEventListener('click', function (e) {

    // outcome = data.tempValue;
    convertCelsiusTemp();
    convertCelsiusTemp2();
    // C = K − (273.15);

    // console.log(outcome + "I was clicked");
})

//Get Radio buttons
fahrenheitValue.addEventListener('click', function (e) {

    // outcome = data.tempValue;
    convertfahrenheitTemp();
    convertfahrenheitTemp2();
    // C = K − (273.15);

    // console.log(outcome + "I was clicked");
})

// convertCelsiusTemp first column
const convertCelsiusTemp = (isKelvin) => {
    if (isKelvin) {
        temp.innerHTML = kelvinValue + 'k'
    } else {
        temp.innerHTML = "Temperature - " + Math.round(kelvinValue - 273.15) + " c";
    }
}

// convertCelsiusTemp second column
const convertCelsiusTemp2 = (isKelvin2) => {
    if (isKelvin2) {
        temp_one.innerHTML = kelvinValue2 + 'k'
    } else {
        temp_one.innerHTML = "Temperature - " + Math.round(kelvinValue2 - 273.15) + " c";

    }
}

// convertfahrenheitTemp first column
const convertfahrenheitTemp = (isKelvin) => {
    if (isKelvin) {
        temp.innerHTML = kelvinValue + 'k'
    } else {
        // 9 / 5 * (K - 273.15) + 32
        temp.innerHTML = "Temperature - " + Math.round(9 / 5 * (kelvinValue - 273.15) + 32) + " f";

    }
}

// convertfahrenheitTemp second column
const convertfahrenheitTemp2 = (isKelvin2) => {
    if (isKelvin2) {
        temp_one.innerHTML = kelvinValue2 + 'k'
    } else {
        // 9 / 5 * (K - 273.15) + 32
        temp_one.innerHTML = "Temperature - " + Math.round(9 / 5 * (kelvinValue2 - 273.15) + 32) + " f";
    }
}

populateOnReload();
populateOnReload2();



//=== convert our object to a JSON string. and setItem
// localStorage.setItem("weather", JSON.stringify(getWeather));

//=== Let's get the item from LocalStorage:
// let storageWeather = localStorage.getItem("weather");
// console.log("String saved in LocalStorage", storageWeather);

//=== convert the LocalStorage string into an object with JSON.parse() and log it to the browser's console:
// let savedWeather = JSON.parse(storageWeather);
// console.log("Weather object:", savedWeather);
// console.log("Weather name:", savedWeather.name);
// console.log(localStorage.getItem("weather"));



// const func = async () => {
//     const resp1 = await fetch('fake.api');
//     const body = await resp1.json();
//     const resp2 = await fetch('api.2', { method: 'POST', body: JSON.stringify({ date: body.bankCode }) })

// }
// const getDataFromLocalStorage = () => {
//     const dataStringified = localStorage.getItem('_fake');
//     console.log(dataStringified);
//     return data && JSON.parse(dataStringified) || null;
// };
